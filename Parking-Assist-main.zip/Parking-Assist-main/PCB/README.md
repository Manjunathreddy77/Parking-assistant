# Printed Circuit Board

The Fritzing (BETA version 0.9.3) program was used to create a PCB design, pictured here:

![](images/PCB-gerber.jpg)

Extended Gerber (RS-274X) files were created and delivered to a PC fab house, PCBWay (pcbway.com), 
which delivered 10 boards in under one week at a total cost of $25 (including shipping). 


